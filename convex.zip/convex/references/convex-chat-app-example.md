# Convex Chat App Example

Complete real-time chat backend with AI responses.

## Schema (`convex/schema.ts`)

```typescript
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  channels: defineTable({ name: v.string() }),
  users: defineTable({ name: v.string() }),
  messages: defineTable({
    channelId: v.id("channels"),
    authorId: v.optional(v.id("users")),
    content: v.string(),
  }).index("by_channel", ["channelId"]),
});
```

## Functions (`convex/index.ts`)

```typescript
import {
  query, mutation,
  internalQuery, internalMutation, internalAction,
} from "./_generated/server";
import { v } from "convex/values";
import OpenAI from "openai";
import { internal } from "./_generated/api";

// Public: create user
export const createUser = mutation({
  args: { name: v.string() },
  returns: v.id("users"),
  handler: async (ctx, args) => {
    return await ctx.db.insert("users", { name: args.name });
  },
});

// Public: create channel
export const createChannel = mutation({
  args: { name: v.string() },
  returns: v.id("channels"),
  handler: async (ctx, args) => {
    return await ctx.db.insert("channels", { name: args.name });
  },
});

// Public: list messages (desc, take 10)
export const listMessages = query({
  args: { channelId: v.id("channels") },
  returns: v.array(v.object({
    _id: v.id("messages"),
    _creationTime: v.number(),
    channelId: v.id("channels"),
    authorId: v.optional(v.id("users")),
    content: v.string(),
  })),
  handler: async (ctx, args) => {
    return await ctx.db.query("messages")
      .withIndex("by_channel", (q) => q.eq("channelId", args.channelId))
      .order("desc").take(10);
  },
});

// Public: send message + schedule AI response
export const sendMessage = mutation({
  args: {
    channelId: v.id("channels"),
    authorId: v.id("users"),
    content: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const channel = await ctx.db.get(args.channelId);
    if (!channel) throw new Error("Channel not found");
    const user = await ctx.db.get(args.authorId);
    if (!user) throw new Error("User not found");
    await ctx.db.insert("messages", {
      channelId: args.channelId,
      authorId: args.authorId,
      content: args.content,
    });
    await ctx.scheduler.runAfter(0, internal.index.generateResponse, {
      channelId: args.channelId,
    });
    return null;
  },
});

// Internal action: generate AI response
const openai = new OpenAI();
export const generateResponse = internalAction({
  args: { channelId: v.id("channels") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const context = await ctx.runQuery(internal.index.loadContext, {
      channelId: args.channelId,
    });
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: context,
    });
    const content = response.choices[0].message.content;
    if (!content) throw new Error("No content in response");
    await ctx.runMutation(internal.index.writeAgentResponse, {
      channelId: args.channelId, content,
    });
    return null;
  },
});

// Internal query: load conversation context
export const loadContext = internalQuery({
  args: { channelId: v.id("channels") },
  returns: v.array(v.object({
    role: v.union(v.literal("user"), v.literal("assistant")),
    content: v.string(),
  })),
  handler: async (ctx, args) => {
    const messages = await ctx.db.query("messages")
      .withIndex("by_channel", (q) => q.eq("channelId", args.channelId))
      .order("desc").take(10);
    const result = [];
    for (const message of messages) {
      if (message.authorId) {
        const user = await ctx.db.get(message.authorId);
        if (!user) throw new Error("User not found");
        result.push({ role: "user" as const, content: `${user.name}: ${message.content}` });
      } else {
        result.push({ role: "assistant" as const, content: message.content });
      }
    }
    return result;
  },
});

// Internal mutation: write AI response
export const writeAgentResponse = internalMutation({
  args: { channelId: v.id("channels"), content: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await ctx.db.insert("messages", {
      channelId: args.channelId, content: args.content,
    });
    return null;
  },
});
```

## Key Patterns Demonstrated

1. **Public vs internal**: `mutation`/`query` for client API, `internal*` for server logic
2. **Scheduling**: `ctx.scheduler.runAfter(0, ...)` to trigger async work
3. **Cross-function calls**: `ctx.runQuery` / `ctx.runMutation` with `FunctionReference`
4. **Index usage**: `withIndex("by_channel", ...)` instead of `filter()`
5. **Type safety**: `as const` for string literals in unions
6. **Null returns**: `returns: v.null()` + `return null` for void functions
